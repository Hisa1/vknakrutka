from rich import print
from cls import cls
import requests
import sys

cls()
token = 'token vk'
v = 5.131

import time

print("Проверка token [red]VK[/red]")
for percent in range(100):
    s = f"[{(percent // 10) * '■'}"
    s += f"{(5 - (percent // 10)) * '○'}] "
    s += f"{percent} %"
    print(s, end="\r")
    time.sleep(0.001)


info = requests.get('https://api.vk.com/method/users.get', params={
        'v': v,
        'name_case': 'Nom',
        'access_token': token,
        'fields': 'photo_max_orig,counters'
    }).json()
if "error" in info:
    print("[red]Неправильный токен VK[/red]")
    sys.exit()

first_name = info["response"][0]["first_name"]
last_name = info["response"][0]["last_name"]

